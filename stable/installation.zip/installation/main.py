import os, site
os.system('pip install pyaudio wave yt-dlp moviepy speechrecognition requests youtube-dl')
os.system('pip uninstall chatterbot')
site.addpackage('./chatterbot', 'chatterbot') #install the modified one made to work with amika
print("Everything should be installed.")